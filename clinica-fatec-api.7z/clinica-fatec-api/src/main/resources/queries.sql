INSERT INTO Medicamento (nome)
VALUES
    ('Paracetamol'),
    ('Ibuprofeno'),
    ('Aspirina'),
    ('Omeprazol'),
    ('Loratadina'),
    ('Amoxicilina'),
    ('Cetirizina'),
    ('Dipirona'),
    ('Ranitidina'),
    ('Cloridrato de Sertralina');


INSERT INTO Exame (nome)
VALUES
    ('Hemograma Completo'),
    ('Colesterol Total'),
    ('Glicose em Jejum'),
    ('Hemoglobina Glicada'),
    ('Teste de Gravidez'),
    ('Ultrassom Abdominal'),
    ('Radiografia de Tórax'),
    ('Ressonância Magnética'),
    ('Eletrocardiograma'),
    ('Colonoscopia');